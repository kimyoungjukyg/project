package com.KL.member.vo;

public class CalendarVO {
private String employeeNo;
private String starttime;
private String endtime;
private String scheduleContent;
private String start;
private String end;
private String title;





public String getScheduleContent() {
	return scheduleContent;
}

public void setScheduleContent(String scheduleContent) {
	this.scheduleContent = scheduleContent;
}

public String getStart() {
	return start;
}

public void setStart(String start) {
	this.start = start;
}

public String getEnd() {
	return end;
}

public void setEnd(String end) {
	this.end = end;
}

public String getEmployeeNo() {
	return employeeNo;
}
public void setEmployeeNo(String employeeNo) {
	this.employeeNo = employeeNo;
}
public String getStarttime() {
	return starttime;
}
public void setStarttime(String starttime) {
	this.starttime = starttime;
}
public String getEndtime() {
	return endtime;
}
public void setEndtime(String endtime) {
	this.endtime = endtime;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}

}
